module leadhunterdesktop

go 1.21
