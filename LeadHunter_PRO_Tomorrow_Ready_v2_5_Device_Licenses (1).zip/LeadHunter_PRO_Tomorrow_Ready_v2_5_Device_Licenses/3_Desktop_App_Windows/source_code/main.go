// LeadHunter PRO Desktop v2.5 – opens the LeadHunter PRO CRM in its own app window.
// © Tony Djurberg Consulting. All rights reserved.
package main

import (
	"bufio"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

const defaultServer = "https://loginleadhunterpro.online/"

func exeDir() string {
	p, err := os.Executable()
	if err != nil {
		return "."
	}
	return filepath.Dir(p)
}

func readConfig() map[string]string {
	cfg := map[string]string{"server": defaultServer, "browser": "auto", "width": "1440", "height": "900"}
	path := filepath.Join(exeDir(), "leadhunter.ini")
	f, err := os.Open(path)
	if err != nil {
		_ = os.WriteFile(path, []byte("; LeadHunter PRO Desktop – © Tony Djurberg Consulting\r\n"+
			"; server = address of your LeadHunter PRO (normal version or WordPress site)\r\n"+
			"server="+defaultServer+"\r\n"+
			"; browser = auto | chrome | edge\r\n"+
			"browser=auto\r\n"+
			"width=1440\r\nheight=900\r\n"), 0644)
		return cfg
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, ";") || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "[") {
			continue
		}
		if i := strings.Index(line, "="); i > 0 {
			cfg[strings.ToLower(strings.TrimSpace(line[:i]))] = strings.TrimSpace(line[i+1:])
		}
	}
	return cfg
}

func findBrowser(pref string) string {
	local := os.Getenv("LOCALAPPDATA")
	pf := os.Getenv("ProgramFiles")
	pf86 := os.Getenv("ProgramFiles(x86)")
	chrome := []string{
		filepath.Join(pf, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(pf86, `Google\Chrome\Application\chrome.exe`),
		filepath.Join(local, `Google\Chrome\Application\chrome.exe`),
	}
	edge := []string{
		filepath.Join(pf86, `Microsoft\Edge\Application\msedge.exe`),
		filepath.Join(pf, `Microsoft\Edge\Application\msedge.exe`),
	}
	var order []string
	switch strings.ToLower(pref) {
	case "edge":
		order = append(edge, chrome...)
	default:
		order = append(chrome, edge...)
	}
	for _, p := range order {
		if p == "" {
			continue
		}
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	return ""
}

func messageBox(title, text string) {
	user32 := syscall.NewLazyDLL("user32.dll")
	mb := user32.NewProc("MessageBoxW")
	t, _ := syscall.UTF16PtrFromString(title)
	m, _ := syscall.UTF16PtrFromString(text)
	mb.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), 0x40)
}

func main() {
	cfg := readConfig()
	server := strings.TrimSpace(cfg["server"])
	if !strings.HasPrefix(server, "http://") && !strings.HasPrefix(server, "https://") {
		server = "https://" + server
	}
	sep := "?"
	if strings.Contains(server, "?") {
		sep = "&"
	}
	url := server + sep + "lhdesktop=1"
	profile := filepath.Join(os.Getenv("LOCALAPPDATA"), "LeadHunterPRO", "Desktop")
	_ = os.MkdirAll(profile, 0755)
	browser := findBrowser(cfg["browser"])
	if browser == "" {
		messageBox("LeadHunter PRO", "Google Chrome or Microsoft Edge was not found.\nThe CRM opens in your default browser instead.\n\n"+url)
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
		return
	}
	args := []string{
		"--app=" + url,
		"--user-data-dir=" + profile,
		"--window-size=" + cfg["width"] + "," + cfg["height"],
		"--no-first-run",
		"--no-default-browser-check",
		"--disable-features=TranslateUI",
		"--lang=sv",
	}
	cmd := exec.Command(browser, args...)
	if err := cmd.Start(); err != nil {
		messageBox("LeadHunter PRO", "Could not start the browser:\n"+err.Error())
	}
}
