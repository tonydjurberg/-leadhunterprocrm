LeadHunter PRO v2.5 – Tomorrow Ready – Device Licenses
© Tony Djurberg Consulting

INNEHÅLL / CONTENTS
  1_Normal_Version_PHP   -> för loginleadhunterpro.online (Namecheap). Se INSTALL.txt
  2_WordPress_Theme      -> WordPress-tema, ladda upp leadhunter-pro.zip. Se INSTALL.txt
  3_Desktop_App_Windows  -> .exe för din dator (super admin). Se INSTALL.txt
Båda versionerna är fristående med egen databas och kan ligga på olika webbhotell.

FÖRSTA INLOGGNING / FIRST LOGIN
  admin / admin123   (byt lösenord under "Konto & lösenord" efter installationen)

EXEMPELKONTON (Exempelbolaget AB) – lösenord: Exempel123!
  exempel.admin, exempel.teamleader, exempel.coach, anna.agent, erik.agent, sara.agent
  Ta bort: Inställningar > Systeminfo > Ta bort exempeldata

DETTA MÅSTE FYLLAS I MED ERA EGNA KONTON (finns inte i systemet från början)
  - WhatsApp Business (Meta Cloud API): Inställningar > WhatsApp (LeadHunter PRO)
    – behövs för att skicka inloggningar, påminnelser och fakturor till företagen.
  - Varje företag: sin egen VoIP-leverantör (SIP/WebRTC, Twilio, 46elks, Plivo eller egen växel)
    och sitt eget WhatsApp under Inställningar. Utan VoIP fungerar "Manuellt läge" (loggar samtal och tid).
  - E-post för "Glömt lösenord" använder serverns e-post (PHP mail / WordPress wp_mail).
